/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit13a;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author zacmurphy
 */
public class FXMLDocumentController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField textFieldPatientId;
    @FXML
    private TextField textFieldFirstName;
    @FXML
    private TextField textFieldLastName;
    @FXML
    private TextField textFieldAge;
    @FXML
    private TextField textFieldZipCode;
    @FXML 
    private TextField textFieldAddress;
    @FXML
    private Button buttonNew;
    @FXML
    private Button buttonUpdate;
    @FXML
    private Button buttonDelete;
    @FXML
    private ListView listViewPatients;
    
    private ObservableList<Patient> patientList = FXCollections.observableArrayList(Patient.extractor);
    private ChangeListener<Patient> patientChangeListener;
    private Patient selectedPatient;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        patientList.add(new Patient(45555, "Alice", "Allison", 50, 55210, "1224 S Street"));
        patientList.add(new Patient(43225, "Ray", "Anderson", 20, 51560, "3224 E Street"));
        patientList.add(new Patient(23325, "Don", "Toliver", 30, 51230, "1214 N Street"));
        patientList.add(new Patient(15225, "Von", "King", 33, 45553, "2222 W Street"));
        listViewPatients.setItems(patientList);
        
        listViewPatients.getSelectionModel().selectedItemProperty().addListener(
            patientChangeListener = (observable, oldValue, newValue) -> {
                // Set the selected Student.
                selectedPatient = newValue;
                
                if (newValue != null) {
                    // Populate the GridView controls with the Student's data.
                    textFieldPatientId.setText("" + selectedPatient.getPatientId());
                    textFieldFirstName.setText(selectedPatient.getFirstName());
                    textFieldLastName.setText(selectedPatient.getLastName());
                    textFieldAge.setText("" + selectedPatient.getAge());
                    
                    textFieldZipCode.setText("" + selectedPatient.getZipCode());
                    textFieldAddress.setText(selectedPatient.getAddress());
                    
                }
                else {
                    // Clear the GridView controls if a Student is not selected.
                    textFieldPatientId.setText("");
                    textFieldFirstName.setText("");
                    textFieldLastName.setText("");
                    textFieldAge.setText("");
                    
                    textFieldZipCode.setText("");
                    textFieldAddress.setText("");
                    
                }
            }
            );
         
        buttonNew.disableProperty().bind(
            textFieldFirstName.textProperty().isEmpty()
                    .or(textFieldLastName.textProperty().isEmpty()));
        
        // Update and Delete Buttons.
        buttonUpdate.disableProperty().bind(listViewPatients.getSelectionModel().selectedItemProperty().isNull());
        buttonDelete.disableProperty().bind(listViewPatients.getSelectionModel().selectedItemProperty().isNull());
    }
 @FXML
    private void buttonNewAction(ActionEvent actionEvent) {
        try{
        // Get data from form controls.
        int patientId = Integer.parseInt(textFieldPatientId.getText());
        String firstName = textFieldFirstName.getText();
        String lastName = textFieldLastName.getText();
        int age = Integer.parseInt(textFieldAge.getText());
        
        int zipCode = Integer.parseInt(textFieldZipCode.getText());
        //IDK WHY ERROR
        String address = textFieldAddress.getText();
        
        // Create Student object.
        Patient patient = new Patient(patientId, firstName, lastName, age,zipCode, address );
        
        // Add the Student to the list.
        patientList.add(patient);
        
        // Select the Student in the ListView.
        listViewPatients.getSelectionModel().select(patient);
        }
        catch(Exception e){
            System.out.println(e);
        }
           
    }

    @FXML
    private void buttonUpdateAction(ActionEvent actionEvent) {
        // Get the Student object the user selected from the ListView.
        try{
        Patient patient = (Patient) listViewPatients.getSelectionModel().getSelectedItem();
        
        // Temporarily remove the change listener while we adjust the Student data.
        listViewPatients.getSelectionModel().selectedItemProperty().removeListener(patientChangeListener);
        
        // Get the updated data from the controls.
        int patientId = Integer.parseInt(textFieldPatientId.getText());
        String firstName = textFieldFirstName.getText();
        String lastName = textFieldLastName.getText();
        int age = Integer.parseInt(textFieldAge.getText());
        
        int zipCode = Integer.parseInt(textFieldZipCode.getText());
        String address = textFieldAddress.getText();
        
        // Update the data in the Student object.
        patient.setPatientId(patientId);
        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setAge(age);
        
        patient.setZipCode(zipCode);
        patient.setAddress(address);
        
        // Add the change listener back in.
        listViewPatients.getSelectionModel().selectedItemProperty().addListener(patientChangeListener);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
        @FXML
    private void buttonDeleteAction(ActionEvent actionEvent) {
        // User has chosen to delete the selected Student.
        // Remove it from the list.
        patientList.remove(selectedPatient);
    }
    
}
