/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit13a;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;
//import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.IntegerProperty;
//import javafx.beans.property.DoubleProperty;
import javafx.util.Callback;
/**
 *
 * @author zacmurphy
 */
public class Patient {
    //creation of the instance variables 
    private IntegerProperty patientId;
    private StringProperty firstName;
    private StringProperty lastName;
    private IntegerProperty age;
    private IntegerProperty zipCode;
    private StringProperty address;
    //constructor setting the form for all of the instance variables 
    public Patient(){
        patientId = new SimpleIntegerProperty(this, "patientId", 0);
        firstName = new SimpleStringProperty(this, "firstName", "");
        lastName = new SimpleStringProperty(this, "lastName", "");
        age = new SimpleIntegerProperty(this, "age", 0);
        zipCode = new SimpleIntegerProperty(this, "zipCode", 0);
        address = new SimpleStringProperty(this, "address", "");
    }
    //constructor that takes in the instance variables 
    public Patient(int inPatientId, String inFirstName, String inLastName, int inAge, int inZipCode, String inAddress){
        patientId = new SimpleIntegerProperty(this, "patientId", inPatientId);
        firstName = new SimpleStringProperty(this, "firstName", inFirstName);
        lastName = new SimpleStringProperty(this, "lastName", inLastName);
        age = new SimpleIntegerProperty(this, "age", inAge);
        zipCode = new SimpleIntegerProperty(this, "zipCode", inZipCode);
        address = new SimpleStringProperty(this, "address", inAddress);
    }
    //Gets and sets for all of the instance variables created 
    public int getPatientId(){
        return patientId.get();
    }
    public IntegerProperty patiendIdProperty(){
        return patientId;
    }
    public void setPatientId(int inPatientId){
        patientId.set(inPatientId);
    }
    public String getFirstName()
    {
        return firstName.get();
    }
    
    public StringProperty firstNameProperty()
    {
        return firstName;
    }
    
    public void setFirstName(String inFirstName)
    {
        firstName.set(inFirstName);
    }
    public String getAddress(){
        return address.get();
    }
    public StringProperty addressProperty(){
        return address;
    }
    public void setAddress(String inAddress){
        address.set(inAddress);
    }
    public int getZipCode(){
        return zipCode.get();
    }
    public IntegerProperty zipCodeProperty(){
        return zipCode;
    }
    public void setZipCode(int inZipCode){
        zipCode.set(inZipCode);
    }
    public String getLastName()
    {
        return lastName.get();
    }
    
    public StringProperty lastNameProperty()
    {
        return lastName;
    }
    
    public void setLastName(String inLastName)
    {
        lastName.set(inLastName);
    }
    
    public int getAge()
    {
        return age.get();
    }
    
    public IntegerProperty ageProperty()
    {
        return age;
    }
    
    public void setAge(int inAge)
    {
        age.set(inAge);
    }
    @Override
    public String toString()
    {
        return firstName.getValue() + " " + lastName.getValue();
    }
    //Equals boolean method that checks if the objects created are equal
    @Override
    public boolean equals(Object object)
    {
        boolean areEqual;
        //chain of ifs checking true or false
        if (this == object)
        {
            areEqual = true;
        }
        else if (object == null)
        {
            areEqual = false;
        }
        else if (getClass() != object.getClass())
        {
            areEqual = false;
        }
        else
        {
            Patient other = (Patient) object;
            
            if (getFirstName().equals(other.getFirstName())
                    && getLastName().equals(other.getLastName())
                    && getAge() == other.getAge()
                    && getPatientId() == other.getPatientId())
            {
                areEqual = true;
            }
            else
            {
                areEqual = false;
            }
        }
        //Return boolean
        return areEqual;
    }
    public static Callback<Patient, Observable[]> extractor = p -> new Observable[]
        {p.lastNameProperty(), p.firstNameProperty()};
}
